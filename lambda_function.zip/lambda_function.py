import json
import boto3
import urllib.request


EC2 = boto3.client('ec2')


def lambda_handler(event, context):
    body = event.get('body')
    try:
        payload = json.loads(body)
        alerts = payload.get('alerts', [])
    except Exception:
        return {"statusCode":400, "body":"invalid payload"}


    for alert in alerts:
        instance_label = alert.get('labels', {}).get('instance', '')
        # Expect instance_label to be private IP (e.g., 10.0.x.x)
        instance_id = get_instance_id_by_private_ip(instance_label)
        if instance_id:
            try:
                EC2.reboot_instances(InstanceIds=[instance_id])
            except Exception as e:
                print('reboot failed', e)
        else:
            print('no instance mapping for', instance_label)


    return {"statusCode":200, "body":"ok"}




def get_instance_id_by_private_ip(private_ip):
    try:
        resp = EC2.describe_instances(Filters=[{'Name':'private-ip-address','Values':[private_ip]}])
        for r in resp.get('Reservations',[]):
            for i in r.get('Instances',[]):
                return i.get('InstanceId')
    except Exception as e:
        print(e)
    return None


